import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load Dataset
df = pd.read_csv("C:\\Users\\raush\\Downloads\\Electric_Vehicle_Population_Data_20250406.csv")  # Replace with your CSV file

print("\n Dataset Overview:")
print(df)

print("\n Head of the dataset:")
print(df.head())

print("\n Tail of the dataset:")
print(df.tail())

print("\n Summary Statistics:")
print(df.describe())

print("\n Information:")
print(df.info())

print("\n Column Names:")
print(df.columns)

print("\n Shape of Dataset:")
print(df.shape)


# ====================== Objective 1 ======================
# Analyze the Growth of EV Registrations Over the Years
yearly_counts = df['Model Year'].value_counts().sort_index()

plt.figure(figsize=(12, 6))
sns.lineplot(x=yearly_counts.index, y=yearly_counts.values, marker='o', linewidth=2.5, color='green')
plt.title('Growth of Electric Vehicle Registrations Over the Years')
plt.xlabel('Model Year')
plt.ylabel('Number of EVs Registered')
plt.grid(True)
plt.tight_layout()
#plt.show()

# ====================== Objective 2 ======================
# EV Distribution by Make
top_makes = df['Make'].value_counts().head(10)
top_makes_df = top_makes.reset_index()
top_makes_df.columns = ['Make', 'Count']

plt.figure(figsize=(10, 6))
sns.barplot(data=top_makes_df, x='Count', y='Make', hue='Make', palette='viridis', legend=False)
plt.title('Top 10 Electric Vehicle Manufacturers')
plt.xlabel('Number of Vehicles')
plt.ylabel('Make')
plt.tight_layout()
#plt.show()

# EV Distribution by Make and Model
df['Make_Model'] = df['Make'] + ' ' + df['Model']
top_models = df['Make_Model'].value_counts().head(10)
top_models_df = top_models.reset_index()
top_models_df.columns = ['Make_Model', 'Count']

plt.figure(figsize=(10, 6))
sns.barplot(data=top_models_df, x='Count', y='Make_Model', hue='Make_Model', palette='magma', legend=False)
plt.title('Top 10 Electric Vehicle Models')
plt.xlabel('Number of Vehicles')
plt.ylabel('Make and Model')
plt.tight_layout()
#plt.show()

# ====================== Objective 3 ======================
# Distribution of EV Types (BEV vs PHEV)
plt.figure(figsize=(6, 6))
type_counts = df['Electric Vehicle Type'].value_counts()
colors = sns.color_palette('pastel')[0:len(type_counts)]
plt.pie(type_counts, labels=type_counts.index, colors=colors, autopct='%1.1f%%', startangle=140)
plt.title('Distribution of Electric Vehicle Types (BEV vs PHEV)')
plt.tight_layout()
#plt.show()

# ====================== Objective 4 ======================
# Top Counties with Highest EV Adoption
top_counties = df['County'].value_counts().head(10)
top_counties_df = top_counties.reset_index()
top_counties_df.columns = ['County', 'Count']

plt.figure(figsize=(12, 6))
sns.barplot(data=top_counties_df, x='County', y='Count', hue='County', palette='coolwarm', legend=False)
plt.title('Top 10 Counties with Highest EV Registrations')
plt.xlabel('County')
plt.ylabel('Number of EVs')
plt.xticks(rotation=45)  # Rotate labels if needed
plt.tight_layout()
#plt.show()



# ====================== Objective 5 ======================
# Electric Range Distribution
plt.figure(figsize=(10, 6))
sns.histplot(df['Electric Range'].dropna(), bins=30, kde=True, color='teal')
plt.title('Distribution of Electric Vehicle Ranges')
plt.xlabel('Electric Range (miles)')
plt.ylabel('Number of Vehicles')
plt.tight_layout()
#plt.show()


# ====================== Objective 6 ======================
# Compare the Electric Range distribution of EVs by Electric Vehicle Type (BEV vs PHEV).
plt.figure(figsize=(10, 6))
sns.boxplot(data=df, x='Electric Vehicle Type', y='Electric Range',
            hue='Electric Vehicle Type', palette='pastel', legend=False)
plt.title('Electric Range Distribution by EV Type')
plt.xlabel('Electric Vehicle Type')
plt.ylabel('Electric Range (miles)')
plt.tight_layout()
#plt.show()

# ====================== Objective 7 ======================
# Use a heatmap to reveal relationships between numerical columns like Electric Range, Base MSRP, and Model Year.
numerical_cols = ['Model Year', 'Electric Range', 'Base MSRP']

# Drop rows with missing values in these columns
heatmap_df = df[numerical_cols].dropna()

# Compute correlation matrix
correlation = heatmap_df.corr()

# Plot heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(correlation, annot=True, cmap='coolwarm', linewidths=1, linecolor='white')
plt.title('Correlation Heatmap: Model Year, Electric Range, and MSRP')
plt.tight_layout()
plt.show()

